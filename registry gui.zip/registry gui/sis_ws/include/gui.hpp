#ifndef ANNOUNCEMENT_HPP
#define ANNOUNCEMENT_HPP

#include <Windows.h>
#include<string>
#include <vector>
#include <iomanip>
using namespace std;

class Announcement {
    protected:
    int textLineCount;
    string title{};
    string text{};
    string promoter{};
    string targetUser{};
    string promoteTime{};
    string readState{};

    //variables for read
    string cur_user_id;
    public:
    Announcement();
    ~Announcement();
    //send function
    void setContent(string title, string text);
    void setPromoter(string promoter);
    void setTarget(string idCode);
    void send();

    //read function
    static int getMaxTxt(const string& idCode);
    void setCurUserId(const string& idCode);
    void readFile(int fileNum);
    string getTitle();
    string getText();
    string getPromoter();
    string getPromoteTime();
    bool getReadState() const;
};

class AnnouncementPage {
public:
    static void messagePage();
};

class Button {
    protected:
    int left = 100, top = 100, right = 300, bottom = 200, ellipsewidth = 0, ellipseheight = 0;
    LPCTSTR defaultText;
    int defaultTextSize;
    int mouseStyle = 0; //0代表正常箭头鼠标，1代表手型鼠标
    LPCTSTR defaultTextFont;
    COLORREF defaultTextColor;
    COLORREF defaultButtonColor;
    COLORREF mouseInButtonColor;
    public:
    Button();
    ~Button();
    void Draw(int topLeft_x, int topLeft_y, int downRight_x, int downRight_y, int el_width, int el_height);
    void setColor(COLORREF theColor, COLORREF mouseInColor);
    void setDefaultText(LPCTSTR defaultStr, int textSize, LPCTSTR textFont, COLORREF textColor);
    void changeWhileMouseInBox(int x,int y);
    void resetMouseStyle();
    bool Check(int x, int y) const;
    void changeButtonColor(COLORREF theColor);
};

class TextBox {
protected:
    int left = 100, right = 300, bottom = 100;  //文本框横线左端点x坐标，右端点x坐标，横线底部y坐标
    int textLen = 0;
    int enter_x = 0;
    int mouseStyle = 0; //0代表正常箭头鼠标，1代表I型鼠标
    bool typing = false;
    LPCTSTR defaultText;
    int defaultTextSize{};
    LPCTSTR defaultTextFont;
    COLORREF defaultTextColor;
    COLORREF defaultBackColor;
    std::vector<char> textInBox;
    bool multiLines = false;
    int lineNumLimit;
    int lineNum;
public:
    TextBox();
    ~TextBox();
    void Draw(int left_x, int right_x, int line_y);
    void setBackColor(COLORREF theColor);
    void setDefaultText(LPCTSTR defaultStr, int textSize, LPCTSTR textFont, COLORREF textColor);
    void initialize(int x, int y);
    void mouseInBoxCheck();
    void changeWhileMouseInBox(int x,int y);
    bool Check(int x, int y);
    void changeLineColor(COLORREF lineColor) const;
    void cursorBlinking() const;
    void Type();
    void setMultiLines(bool isMultiLines);
    void setLineLimit(int lineNum);
    std::string value();
};

class TextBoxPage {
protected:
    string input;
public:
    TextBoxPage();
    ~TextBoxPage();
    bool createTextBoxPage(const string& title);
    string getInput();
};
#endif //ANNOUNCEMENT_HPP
