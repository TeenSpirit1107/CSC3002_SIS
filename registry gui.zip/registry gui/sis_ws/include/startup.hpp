#ifndef STARTUP_HPP
#define STARTUP_HPP
class Startup {
    public:
    static void loadFirstPage();
};
#endif //STARTUP_HPP
