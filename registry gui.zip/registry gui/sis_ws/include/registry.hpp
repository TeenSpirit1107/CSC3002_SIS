# ifndef REGISTRY_HPP
# define REGISTRY_HPP

// std lib
#include<string>

// packages
#include "client.hpp"
class Registry: public Client{

protected:
    int class_num = 0;

public:
    Registry();
    static void createRegistryPage();
    static void drawWidget();
    static void claim_course();
    static void claim_class();
    static void arrangeClassPage();
    ~Registry();
};
# endif