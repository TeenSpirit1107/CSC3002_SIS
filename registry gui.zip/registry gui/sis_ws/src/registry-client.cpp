#include <conio.h>
#include <windows.h>
#include <string>
#include <unistd.h>
#include <iostream>
#include <easyx.h>
#include <sstream>
#include <cstdio>
#include <fstream>
#include <utility>
#include <iomanip>
#include <course.hpp>
#include <registry.hpp>
#include <client.hpp>
#include <gui.hpp>
#include <map>
#include <startup.hpp>


Registry::Registry() {
    this->userID = "0000000";
    this->userName = "Registry";
    this->userType = 'a';
    this->passcode = "1234567890";
    printf("Registry Connected\n");
}

Registry::~Registry() {
    printf("disconnecting from registry\n");
}

void courseManagementPage();

void messagePage();
void page2Animation(){  //第二页出现的动画，原理于logInZone相同
    const int changeRate = 120;
    constexpr double deltaR = (186.0 - 138.0)/changeRate;
    constexpr double deltaG = (204.0 - 188.0)/changeRate;
    constexpr double deltaB = (217.0 - 209.0)/changeRate;
    double curR = 138;
    double curG = 188;
    double curB = 209;
    int curTop = -720;
    int curBottom = 0;
    setfillcolor(RGB(curR,curG,curB));
    for (int i = 0; i < changeRate; i++){
        usleep(1000);
        curR += deltaR;
        curG += deltaG;
        curB += deltaB;
        setfillcolor(RGB(curR,curG,curB));
        curTop += 6;
        curBottom += 6;
        solidrectangle(0,curTop,1280,curBottom);
    }
}
void Registry::drawWidget() {
    setbkcolor(RGB(186, 204, 217));
    cleardevice();
    setfillcolor(RGB(17, 101, 154));
    solidrectangle(0, 0, 250, 140);
    setfillcolor(RGB(216, 227, 231));
    solidrectangle(251, 0, 1280, 140);
    RECT r_title = {30, 10, 220, 500};
    setbkcolor(RGB(17, 101, 154));
    settextcolor(WHITE);
    settextstyle(28, 0, _T("Arial Rounded MT Bold"));
    drawtext(_T("Integrated\nStudent\nInformation\nSystem"), &r_title, DT_LEFT | DT_TOP);
    RECT r = { 280,90,1000,130 };
    settextcolor(WHITE);
    setbkcolor(RGB(216, 227, 231));
    settextcolor(RGB(17, 101, 154));
    settextstyle(40, 0, _T("Arial Rounded MT Bold"));
    drawtext(_T("Welcome! USERNAME"), &r, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    Button messageButton;
    messageButton.setColor(RGB(17, 101, 154), RGB(92, 179, 204));
    messageButton.Draw(100, 200, 350, 260, 5, 5);
    messageButton.setDefaultText(_T("Message"), 24, _T("Arial"), WHITE);
    Button courseManagementButton;
    courseManagementButton.setColor(RGB(17, 101, 154), RGB(92, 179, 204));
    courseManagementButton.Draw(100, 300, 350, 360, 5, 5);
    courseManagementButton.setDefaultText(_T("Course Management"), 24, _T("Arial"), WHITE);
    Button classManagementButton;
    classManagementButton.setColor(RGB(17, 101, 154), RGB(92, 179, 204));
    classManagementButton.Draw(100, 400, 350, 460, 5, 5);
    classManagementButton.setDefaultText(_T("Class Management"), 24, _T("Arial"), WHITE);
    Button arrangeClassButton;
    arrangeClassButton.setColor(RGB(17, 101, 154), RGB(92, 179, 204));
    arrangeClassButton.Draw(100, 500, 350, 560, 5, 5);
    arrangeClassButton.setDefaultText(_T("Class Management"), 24, _T("Arial"), WHITE);
    Button logOutButton;
    logOutButton.setColor(RGB(73, 92,105), RGB(94, 121, 135));
    logOutButton.Draw(1100, 80, 1220, 120, 5, 5);
    logOutButton.setDefaultText(_T("Log Out"), 25, _T("Arial Rounded MT Bold"), WHITE);

    ExMessage mouseMonitor{};
    int to_do = 0;
    while(true) {  //第二页的鼠标事件监测
        mouseMonitor = getmessage(EX_MOUSE);
        const int x = mouseMonitor.x;
        const int y = mouseMonitor.y;
        messageButton.changeWhileMouseInBox(x, y);  //启用控件的鼠标样式改变函数，达到在某控件触发时改变鼠标样式的效果
        courseManagementButton.changeWhileMouseInBox(x, y);
        classManagementButton.changeWhileMouseInBox(x, y);
        logOutButton.changeWhileMouseInBox(x ,y);
        arrangeClassButton.changeWhileMouseInBox(x ,y);
        if (mouseMonitor.message == WM_LBUTTONDOWN) {
            if (messageButton.Check(x, y)) {
                usleep(5000);
                messageButton.resetMouseStyle();
                to_do = 1;
                break;
            }
            if (courseManagementButton.Check(x, y)) {
                usleep(5000);
                courseManagementButton.resetMouseStyle();
                to_do = 2;
                break;
            }
            if (classManagementButton.Check(x, y)) {
                usleep(5000);
                classManagementButton.resetMouseStyle();
                to_do = 3;
                break;
            }
            if (arrangeClassButton.Check(x, y)) {
                usleep(5000);
                arrangeClassButton.resetMouseStyle();
                to_do = 4;
                break;
            }
            if (logOutButton.Check(x, y)){
                usleep(5000);
                logOutButton.resetMouseStyle();
                to_do = 5;
                break;
            }
        }
    }
    if (to_do == 1) {
        AnnouncementPage::messagePage();
    }
    else if (to_do == 2) {
        claim_course();
    }
    else if (to_do == 3) {
        claim_class();
    }
    else if (to_do == 4) {
        arrangeClassPage();
    }
    else if (to_do == 5) {
        Startup::loadFirstPage();
    }
}
void Registry::createRegistryPage() {
    page2Animation();
    drawWidget();
}


struct node {
    string filename;
    node *nxt;
    node *prv;
    explicit node(string s);
};

node::node(string s): filename(std::move(s)), nxt(nullptr), prv(nullptr) {}

void insert_at_tail(node *head, string filename) {
    node *new_node = new node(std::move(filename));
    node *p = head;
    while (p->nxt != head) p = p->nxt;
    new_node->nxt = p->nxt;
    new_node->prv = p;
    head->prv = new_node;
    p->nxt = new_node;
}
void print_list(node *head) {
    if (head == nullptr) return;
    node *p = head;
    bool flag = true;
    while(p != head or flag) {
        printf("%s\n", p->filename.c_str());
        p = p->nxt;
        flag = false;
    }
}
void print_list_rev(node *head) {
    if (head == nullptr) return;
    node *p = head->prv;
    bool flag = true;
    while(p != head->prv or flag) {
        printf("%s\n", p->filename.c_str());
        p = p->prv;
        flag = false;
    }
}
void list_delete(node *&head, node *p) {
    if(p == head) head = head->nxt;
    p->nxt->prv = p->prv;
    p->prv->nxt = p->nxt;
    delete p;
}

void pass_process(string fn) {
    string course_path = ".\\sis_ws\\data_repo\\course_claim\\registry\\" + fn;
    ifstream course_file(course_path);
    if (!course_file.is_open()) {
        cout << "could not open file " << course_path << endl;
    }
    string course_name;
    getline(course_file, course_name);
    string prof_code;
    getline(course_file, prof_code);
    string precourse_code;
    getline(course_file, precourse_code);
    cout << "Approved " << course_name << prof_code << precourse_code << endl;
    int num_limit;
    bool year_lmt[7] = {false, false, false, false, false, false, false};
    course_file >> num_limit;
    for (int j = 0; j < num_limit; j++) {
        int t;
        course_file >> t;
        year_lmt[t-1] = true;
    }
    string comment;
    getline(course_file, comment);
    getline(course_file, comment);
    course_file.close();

    TextBoxPage course_code_page;
    if (course_code_page.createTextBoxPage("Enter course code:")) {
        string course_code = course_code_page.getInput();
        string work_dir = ".\\sis_ws\\data_repo\\course_claim\\staff\\"+prof_code+"_succ.txt";
        FILE *file = fopen(work_dir.c_str(), "a+");
        fprintf(file, "%s\n", course_code.c_str());
        fprintf(file, "%s\n", course_name.c_str());
        fclose(file);
        work_dir = ".\\sis_ws\\data_repo\\course\\";
        file = fopen((work_dir+"Course Number.txt").c_str(), "r");
        int n;
        fscanf(file, "%d", &n);
        fclose(file);
        file = fopen((work_dir+"Course Number.txt").c_str(), "w");
        fprintf(file, "%d\n", n+1);
        fclose(file);

        file = fopen((work_dir+"Course List.txt").c_str(), "a");
        fprintf(file, "%s\n", course_code.c_str());
        fclose(file);

        file = fopen((work_dir+course_code+".txt").c_str(), "w");
        fprintf(file, "%s\n", course_name.c_str());
        fprintf(file, "%s\n", prof_code.c_str());
        fprintf(file, "%s\n", precourse_code.c_str());
        fprintf(file, "%d ", num_limit);
        for (int i = 0; i < 7; i++) if (year_lmt[i]) fprintf(file, "%d ", i+1); fprintf(file, "\n");
        fprintf(file, "%s\n", comment.c_str());
        fclose(file);

        file = fopen((work_dir+course_code+"_class_arrange.txt").c_str(), "w");
        fprintf(file, "0\n");
        fclose(file);

        Announcement course_pass;
        course_pass.setContent("Course application approved", "You application of adding " + course_name + " has been approved! The course code is " + course_code + ".\nYou can check weekly schedule now.");
        course_pass.setPromoter("Registry");
        course_pass.setTarget(prof_code);
        course_pass.send();
    }
}
void fail_process(string fn) {
    string course_path = ".\\sis_ws\\data_repo\\course_claim\\registry\\" + fn;
    ifstream course_file(course_path);
    if (!course_file.is_open()) {
        cout << "could not open file " << course_path << endl;
    }
    string course_name;
    getline(course_file, course_name);
    string prof_code;
    getline(course_file, prof_code);
    course_file.close();

    TextBoxPage reason_page;
    if (reason_page.createTextBoxPage("Reason:")) {
        string reason;
        reason = reason_page.getInput();
        string work_dir = ".\\sis_ws\\data_repo\\course_claim\\staff\\"+prof_code+"_fail.txt";
        FILE *file = fopen(work_dir.c_str(), "a+");
        fprintf(file, "%s\n", course_name.c_str());
        fprintf(file, "%s\n", reason.c_str());
        fclose(file);

        Announcement course_fail;
        course_fail.setContent("Course application failed", "You application of adding " + course_name + " has been rejected! Sorry about that.\nReasons:" + reason);
        course_fail.setPromoter("Registry");
        course_fail.setTarget(prof_code);
        course_fail.send();
    }
}

void course_display(string fn) {
    printf("claiming course %s\n", fn.c_str());
    string course_path = ".\\sis_ws\\data_repo\\course_claim\\registry\\" + fn;
    ifstream course_file(course_path);
    if (!course_file.is_open()) {
        cout << "could not open file " << course_path << endl;
    }
    string course_name;
    getline(course_file, course_name);
    string prof_code;
    getline(course_file, prof_code);
    string precourse_code;
    getline(course_file, precourse_code);
    int num_limit;
    bool year_lmt[7] = {false, false, false, false, false, false, false};
    string available_year = "Available Years:";
    course_file >> num_limit;
    for (int j = 0; j < num_limit; j++) {
        int t;
        course_file >> t;
        year_lmt[t-1] = true;
        if (year_lmt[t-1]) {
            available_year += " Year " + to_string(t);
        }
    }
    string comment;
    getline(course_file, comment);
    getline(course_file, comment);
    course_file.close();
    setfillcolor(RGB(186, 204, 217));
    solidrectangle(0, 0, 1280, 495);
    RECT r1 = { 200, 150, 1080, 175 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(("Course Name: " + course_name).c_str(), &r1, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT r2 = { 200, 190, 1080, 215 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(("Prof ID: " + prof_code).c_str(), &r2, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    // [todo] get prof's name by id, cooperate with tym
    RECT r3 = { 200, 230, 1080, 255 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(("Prerequisites: " + precourse_code).c_str(), &r3, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT r4 = { 200, 270, 1080, 295 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(available_year.c_str(), &r4, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT r5 = { 200, 310, 1080, 540 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(comment.c_str(), &r5, DT_LEFT | DT_WORDBREAK);
}

void Registry::claim_course() {
    setbkcolor(RGB(186, 204, 217));
    cleardevice();
    Button previousPageButton;
    previousPageButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    previousPageButton.Draw(200, 560, 400, 600, 5, 5);
    previousPageButton.setDefaultText(_T("Previous Page"), 24, _T("Arial"), WHITE);
    Button nextPageButton;
    nextPageButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    nextPageButton.Draw(500, 560, 700, 600, 5, 5);
    nextPageButton.setDefaultText(_T("Next Page"), 24, _T("Arial"), WHITE);
    Button backButton;
    backButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    backButton.Draw(800, 560, 1000, 600, 5, 5);
    backButton.setDefaultText(_T("Back"), 24, _T("Arial"), WHITE);
    Button approveButton;
    approveButton.setColor(RGB(92, 179, 204), RGB(179, 101, 154));
    approveButton.Draw(200, 500, 400, 540, 5, 5);
    approveButton.setDefaultText(_T("Approve"), 24, _T("Arial"), WHITE);
    Button rejectButton;
    rejectButton.setColor(RGB(92, 179, 204), RGB(179, 101, 154));
    rejectButton.Draw(500, 500, 700, 540, 5, 5);
    rejectButton.setDefaultText(_T("Reject"), 24, _T("Arial"), WHITE);


    cout << "claiming course" << endl;
    string work_dir = ".\\sis_ws\\data_repo\\course_claim\\registry\\"; // [todo] set work dir
    string index_dir = work_dir + "to_claim_list.txt";
    FILE *file = fopen(index_dir.c_str(), "r");
    if (!file) {
        cout << "could not open file " << index_dir << endl;
    } else {
        int n;
        fscanf(file, "%d", &n);
        printf("%d to be claim\n", n);
        char temp_fn[20];
        fscanf(file, "%s", temp_fn);
        node *head = new node(temp_fn);
        head->nxt = head; head->prv = head;
        for (int i = 1; i < n; i++) {
            char temp_fn[20];
            fscanf(file, "%s", temp_fn);
            insert_at_tail(head, temp_fn);
        }
        printf("claiming course list\n");
        print_list(head);
        node *p = head;


        ExMessage mouseMonitor{};
        int to_do = 0;

        string fn = p->filename;
        string course_path = ".\\sis_ws\\data_repo\\course_claim\\registry\\" + fn;
        course_display(fn);
        bool isDeleted = false;
        while(true) {
            mouseMonitor = getmessage(EX_MOUSE);
            const int x = mouseMonitor.x;
            const int y = mouseMonitor.y;
            previousPageButton.changeWhileMouseInBox(x, y);
            nextPageButton.changeWhileMouseInBox(x, y);  //启用控件的鼠标样式改变函数，达到在某控件触发时改变鼠标样式的效果
            backButton.changeWhileMouseInBox(x, y);
            approveButton.changeWhileMouseInBox(x, y);
            rejectButton.changeWhileMouseInBox(x, y);
            if (mouseMonitor.message == WM_LBUTTONDOWN) {
                if (previousPageButton.Check(x, y)) {
                    usleep(5000);
                    previousPageButton.resetMouseStyle();
                        p = p->prv;
                        fn = p->filename;
                        course_display(fn);
                }
                if (nextPageButton.Check(x, y)) {
                    usleep(5000);
                    nextPageButton.resetMouseStyle();
                        p = p->nxt;
                        fn = p->filename;
                        course_display(fn);
                }
                if (backButton.Check(x, y)) {
                    usleep(5000);
                    backButton.resetMouseStyle();
                    to_do = 1;
                    break;
                }
                if (approveButton.Check(x, y)) {
                    usleep(5000);
                    approveButton.resetMouseStyle();

                    pass_process(fn);
                    course_path = ".\\sis_ws\\data_repo\\course_claim\\registry\\" + fn;
                    isDeleted = true;
                    remove(course_path.c_str());
                }
                if (rejectButton.Check(x, y)) {
                    usleep(5000);
                    rejectButton.resetMouseStyle();

                    fail_process(fn);
                    course_path = ".\\sis_ws\\data_repo\\course_claim\\registry\\" + fn;
                    isDeleted = true;
                    remove(course_path.c_str());
                }
                if (isDeleted) {
                    p = p->nxt;
                    list_delete(head, p->prv);
                    n--;
                    FILE *list_file = fopen(index_dir.c_str(), "w");
                    if (!list_file) {
                        cout << "could not open file " << index_dir << endl;
                    } else {
                        fprintf(list_file, "%d\n", n);
                        p = head;
                        for (int i = 0; i < n; i++, p = p->nxt) {
                            fprintf(list_file, "%s\n", p->filename.c_str());
                        }
                        fclose(list_file);
                    }
                    to_do = 2;
                    break;
                }
            }
        }

        switch (to_do) {
            case 1:
                drawWidget();
            break;
            case 2:
                claim_course();
            break;
        }
        fclose(file);

        printf("all claims are done\n");
    }
}
string checkCourseCode(string courseCode) {
    cout << "checking course code: " << courseCode << endl;
    string work_dir = ".\\sis_ws\\data_repo\\course\\";
    string index_dir = work_dir + courseCode + ".txt";
    ifstream course_file(index_dir);
    if (!course_file.is_open()) {
        cout << "could not open file " << courseCode << endl;
        return "DNE";
    }
    string course_name;
    getline(course_file, course_name);
    course_file.close();
    return course_name;
}
short getClassNum() {
    cout << "checking class code" << endl;
    string work_dir = ".\\sis_ws\\data_repo\\class\\Class Number.txt";
    FILE *file = fopen(work_dir.c_str(), "r");
    short n;
    fscanf(file, "%hd", &n);
    return n;
}
void class_pass_process(string fn) {
    string class_path = ".\\sis_ws\\data_repo\\class_claim\\registry\\" + fn;
    ifstream class_file(class_path);
    if (!class_file.is_open()) {
        cout << "could not open file " << class_path << endl;
    } else {
        string courseName, courseCode;
        getline(class_file, courseCode);
        courseName = checkCourseCode(courseCode);
        if(courseName == "DNE") {
            printf("could not find course %s\n", courseCode.c_str());
            class_file.close();
        }
        cout << "Course Name: " << courseName << endl;
        string prof_code;
        getline(class_file, prof_code);
        int N, M;
        int lec[28];
        int tut[28];
        class_file >> N;
        for (int i = 0; i < N; i++) class_file >> lec[i];
        class_file >> M;
        for (int i = 0; i < M; i++) class_file >> tut[i];
        class_file.close();
        short classCode = getClassNum()+short(1);

        string work_dir = ".\\sis_ws\\data_repo\\class_claim\\staff\\"+prof_code+"_succ.txt";
        FILE *file = fopen(work_dir.c_str(), "a+");
        fprintf(file, "%s\n", courseCode.c_str());
        fprintf(file, "%04hd\n", classCode);
        fclose(file);

        work_dir = ".\\sis_ws\\data_repo\\staff\\"+prof_code+".txt"; // [todo] negotiate with tym
        file = fopen(work_dir.c_str(), "a+");
        fprintf(file, "%hd\n", classCode);
        fclose(file);

        work_dir = ".\\sis_ws\\data_repo\\class\\Class Number.txt";
        file = fopen(work_dir.c_str(), "r");
        int n;
        fscanf(file, "%d", &n);
        fclose(file);
        file = fopen(work_dir.c_str(), "w");
        fprintf(file, "%d\n", n+1);
        fclose(file);

        work_dir = ".\\sis_ws\\data_repo\\class\\"+to_string(classCode)+".txt";
        file = fopen(work_dir.c_str(), "a+");
        fprintf(file, "%s\n", prof_code.c_str());
        fprintf(file, "%s\n", courseCode.c_str());
        fprintf(file, "%d\n", N);
        for (int i = 0; i < N; i++) fprintf(file, "%d\n", lec[i]);
        fprintf(file, "%d\n", M);
        for (int i = 0; i < M; i++) fprintf(file, "%d\n", tut[i]);
        fclose(file);

        Announcement class_pass;
        class_pass.setContent("Class application approved", "You application of adding class to " + courseCode + " has been approved!\nYou can check weekly schedule now.");
        class_pass.setPromoter("Registry");
        class_pass.setTarget(prof_code);
        class_pass.send();
    }

}
void class_fail_process(string fn) {
    string class_path = ".\\sis_ws\\data_repo\\class_claim\\registry\\" + fn;
    ifstream class_file(class_path);
    if (!class_file.is_open()) {
        cout << "could not open file " << class_path << endl;
    }
    string courseCode;
    getline(class_file, courseCode);
    string prof_code;
    getline(class_file, prof_code);
    class_file.close();

    TextBoxPage reason_page;
    if (reason_page.createTextBoxPage("Reason:")) {
        string reason;
        reason = reason_page.getInput();
        string work_dir = ".\\sis_ws\\data_repo\\class_claim\\staff\\"+prof_code+"_fail.txt";
        FILE *file = fopen(work_dir.c_str(), "a+");
        fprintf(file, "%s\n", courseCode.c_str());
        fprintf(file, "%s\n", reason.c_str());
        fclose(file);

        Announcement class_fail;
        class_fail.setContent("Class application rejected", "You application of adding class to " + courseCode + " has been rejected! Sorry about that.\nReasons:" + reason);
        class_fail.setPromoter("Registry");
        class_fail.setTarget(prof_code);
        class_fail.send();
    }
}

void class_display(string fn) {
    string class_path = ".\\sis_ws\\data_repo\\class_claim\\registry\\" + fn;
    ifstream class_file(class_path);
    if (!class_file.is_open()) {
        cout << "could not open file " << class_path << endl;
    }
    string courseName, courseCode;
    getline(class_file, courseCode);
    courseName = checkCourseCode(courseCode);
    if(courseName == "DNE") {
        printf("could not find course %s\n", courseCode.c_str());
        class_file.close();
    }
    cout << "Course Name: " << courseName << endl;
    string prof_code;
    getline(class_file, prof_code);
    int N, M;
    int lec[28];
    int tut[28];
    class_file >> N;
    for (int i = 0; i < N; i++) class_file >> lec[i];
    class_file >> M;
    for (int i = 0; i < M; i++) class_file >> tut[i];
    class_file.close();
    setfillcolor(RGB(186, 204, 217));
    solidrectangle(0, 0, 1280, 495);
    RECT r1 = { 200, 150, 1080, 175 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(("Course Name: " + courseName).c_str(), &r1, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT r2 = { 200, 190, 1080, 215 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(("Course Code: " + courseCode).c_str(), &r2, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT r3 = { 200, 230, 1080, 255 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(("Prof ID: " + prof_code).c_str(), &r3, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    // [todo] get prof's name by id, cooperate with tym
    string lectures;
    for (int i = 0; i < N; i++) {
        lectures += to_string(lec[i]) + " ";
    }
    RECT r4 = { 200, 270, 1080, 295 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(("Lectures: " + lectures).c_str(), &r4, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    string tutorials;
    for (int i = 0; i < M; i++) {
        tutorials += to_string(tut[i]) + " ";
    }
    RECT r5 = { 200, 310, 1080, 335 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0,"Arial");
    drawtext(("Tutorials: " + tutorials).c_str(), &r5, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
}
void Registry::claim_class() {
    setbkcolor(RGB(186, 204, 217));
    cleardevice();
    Button previousPageButton;
    previousPageButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    previousPageButton.Draw(200, 560, 400, 600, 5, 5);
    previousPageButton.setDefaultText(_T("Previous Page"), 24, _T("Arial"), WHITE);
    Button nextPageButton;
    nextPageButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    nextPageButton.Draw(500, 560, 700, 600, 5, 5);
    nextPageButton.setDefaultText(_T("Next Page"), 24, _T("Arial"), WHITE);
    Button backButton;
    backButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    backButton.Draw(800, 560, 1000, 600, 5, 5);
    backButton.setDefaultText(_T("Back"), 24, _T("Arial"), WHITE);
    Button approveButton;
    approveButton.setColor(RGB(92, 179, 204), RGB(179, 101, 154));
    approveButton.Draw(200, 500, 400, 540, 5, 5);
    approveButton.setDefaultText(_T("Approve"), 24, _T("Arial"), WHITE);
    Button rejectButton;
    rejectButton.setColor(RGB(92, 179, 204), RGB(179, 101, 154));
    rejectButton.Draw(500, 500, 700, 540, 5, 5);
    rejectButton.setDefaultText(_T("Reject"), 24, _T("Arial"), WHITE);


    cout << "claiming class" << endl;
    string work_dir = ".\\sis_ws\\data_repo\\class_claim\\registry\\";
    string index_dir = work_dir + "to_claim_list.txt";
    FILE *file = fopen(index_dir.c_str(), "r");
    if (!file) {
        cout << "could not open file " << index_dir << endl;
    } else {
        int n;
        fscanf(file, "%d", &n);
        printf("%d to be claim\n", n);
        char temp_fn[20];
        fscanf(file, "%s", temp_fn);
        node *head = new node(temp_fn);
        head->prv = head; head->nxt = head;
        for (int i = 1; i < n; i++) {
            fscanf(file, "%s", temp_fn);
            insert_at_tail(head, temp_fn);
        }
        printf("class claim list\n");
        print_list(head);
        node *p = head;

        ExMessage mouseMonitor{};
        int to_do = 0;
        string fn = p->filename;
        string class_path = ".\\sis_ws\\data_repo\\class_claim\\registry\\" + fn;
        class_display(fn);
        bool isDeleted = false;

        while(true) {
            mouseMonitor = getmessage(EX_MOUSE);
            const int x = mouseMonitor.x;
            const int y = mouseMonitor.y;
            previousPageButton.changeWhileMouseInBox(x, y);
            nextPageButton.changeWhileMouseInBox(x, y);  //启用控件的鼠标样式改变函数，达到在某控件触发时改变鼠标样式的效果
            backButton.changeWhileMouseInBox(x, y);
            approveButton.changeWhileMouseInBox(x, y);
            rejectButton.changeWhileMouseInBox(x, y);

            if (mouseMonitor.message == WM_LBUTTONDOWN) {
                if (previousPageButton.Check(x, y)) {
                    usleep(5000);
                    previousPageButton.resetMouseStyle();
                    p = p->prv;
                    fn = p->filename;
                    class_display(fn);
                }
                if (nextPageButton.Check(x, y)) {
                    usleep(5000);
                    nextPageButton.resetMouseStyle();
                    p = p->nxt;
                    fn = p->filename;
                    class_display(fn);
                }
                if (backButton.Check(x, y)) {
                    usleep(5000);
                    backButton.resetMouseStyle();
                    to_do = 1;
                    break;
                }
                if (approveButton.Check(x, y)) {
                    usleep(5000);
                    approveButton.resetMouseStyle();

                    class_pass_process(fn);
                    class_path = ".\\sis_ws\\data_repo\\class_claim\\registry\\" + fn;
                    isDeleted = true;
                    remove(class_path.c_str());
                }
                if (rejectButton.Check(x, y)) {
                    usleep(5000);
                    rejectButton.resetMouseStyle();

                    class_fail_process(fn);
                    class_path = ".\\sis_ws\\data_repo\\class_claim\\registry\\" + fn;
                    isDeleted = true;
                    remove(class_path.c_str());
                }
                if (isDeleted) {
                    p = p->nxt;
                    list_delete(head, p->prv);
                    n--;
                    FILE *list_file = fopen(index_dir.c_str(), "w");
                    if (!list_file) {
                        cout << "could not open file " << index_dir << endl;
                    } else {
                        fprintf(list_file, "%d\n", n);
                        p = head;
                        for (int i = 0; i < n; i++, p = p->nxt) {
                            fprintf(list_file, "%s\n", p->filename.c_str());
                        }
                        fclose(list_file);
                    }
                    to_do = 2;
                    break;
                }
            }
        }
        switch (to_do) {
            case 1:
                drawWidget();
            break;
            case 2:
                claim_class();
            break;
        }
        fclose(file);
        printf("all claims are done\n");
    }
}

typedef struct classroom{
    int capacity;
    int cnt;
    string location;
    bool usable;
    bool lec_timeslot[28], tut_timeslot[21];
    classroom *nxt;
    explicit classroom(int capacity, string location, bool usable, int cnt=0, classroom *nxt = nullptr) {
        this->capacity = capacity;
        this->location = std::move(location);
        this->usable = usable;
        this->nxt = nxt;
        this->cnt = cnt;
        for (int i = 0; i < 28; i++) this->lec_timeslot[i] = true;
        for (int i = 0; i < 21; i++) this->tut_timeslot[i] = true;
    }
}CR;



void output_usable_classroom(CR *head[], int kinds_cr) {
    for (int i = 0; i < kinds_cr; i++) {
        printf("capacity: %d\n", head[i]->capacity);
        for (CR *j = head[i]->nxt; j != nullptr; j = j->nxt) printf("location: %s usable: %d  ", j->location.c_str(), j->usable);
        printf("\n");
    }
}
map<int, int> mp;
int load_classroom(CR *head[]) {
    int cnt = 0;
    string index_path = ".\\sis_ws\\data_repo\\class\\classroom.txt";
    FILE *file = fopen(index_path.c_str(), "r");
    int kinds_cr;
    fscanf(file, "%d", &kinds_cr);
    for(int i = 0; i < kinds_cr; i++) {
        int capacity;
        fscanf(file, "%d", &capacity);
        head[i]->capacity = capacity;
        mp[capacity] = i;
        int num_classroom;
        fscanf(file, "%d", &num_classroom);
        CR *p = head[i];
        for(int j = 0; j < num_classroom; j++) {
            string location;
            int usable;
            char fn[20];
            fscanf(file, "%s", fn);
            location = string(fn);
            fscanf(file, "%d", &usable);
            CR *new_node = new CR(capacity, location, bool(usable), cnt++);
            p->nxt = new_node;
            p = p->nxt;
        }
    }
    fclose(file);
    return kinds_cr;
}

void classroom_arrangement() {
    cout << "classroom_arrangement" << endl;
    string work_dir = ".\\sis_ws\\data_repo\\class_claim\\registry\\to_claim_list.txt";
    FILE *file = fopen(work_dir.c_str(), "r");
    int n;
    fscanf(file, "%d", &n);
    fclose(file);
    if(n != 0) printf("Warning: some classes haven't been approved\n");

    work_dir = ".\\sis_ws\\data_repo\\class\\";
    string index_path = work_dir + "Class Number.txt";
    file = fopen(index_path.c_str(), "r");
    fscanf(file, "%d", &n);
    fclose(file);

    // load classroom
    CR *heads[50];
    for (int i = 0; i < 50; i++) heads[i] = new CR(0, "TBA", false);
    int kinds_cr = load_classroom(heads);
    output_usable_classroom(heads, kinds_cr);

    Course *course[n];
    for(short i = 1; i <= n; i++) {
        course[i] = new Course(i);
        int cap = course[i]->capacity;
        int num_lec = course[i]->num_lec, num_tut = course[i]->num_tut;
        for (int j = 0; j < num_lec; j++) {
            CR *head = heads[mp[cap]], *p = head->nxt;
            while (p != nullptr && (!p->usable || !p->lec_timeslot[course[i]->lec[j]-1])) {
                printf("%s %d %d %d\n", p->location.c_str(), p->usable, p->lec_timeslot[course[i]->lec[j]-1], course[i]->lec[j]);
                p = p->nxt;
            }
            if (p == nullptr) printf("Warning: class %hd lec %d can't be arranged\n", course[i]->classCode, course[i]->lec[j]);
            else {
                p->lec_timeslot[course[i]->lec[j]-1] = false;
                printf("%s ->lec_timeslot[%d] = false, %d occupied\n", p->location.c_str(), course[i]->lec[j], i);
                course[i]->lec_classroom[j] = p->location;
            }
        }
        for (int j = 0; j < num_tut; j++) {
            CR *head = heads[mp[cap]], *p = head;
            while (p != nullptr && (!p->usable || !p->lec_timeslot[course[i]->tut[j]-1])) p = p->nxt;
            if (p == nullptr) printf("warning: class %hd tut %d cannot be arranged\n", course[i]->classCode, course[i]->tut[j]);
            else {
                p->tut_timeslot[course[i]->tut[j]-1] = false;
                course[i]->tut_classroom[j] = p->location;
            }
        }
    }

    for (short i = 1; i <= n; i++) {
        course[i]->print2File();
        printf("%d\n", course[i]->capacity);
        printf("lec:\n");
        for(int j = 0; j < course[i]->num_lec; j++) {
            printf("%d %d %s\n", course[i]->classCode, course[i]->lec[j], course[i]->lec_classroom[j].c_str());
        }
        printf("tut:\n");
        for (int j = 0; j < course[i]->num_tut; j++) {
            printf("%d %d %s\n", course[i]->classCode, course[i]->tut[j], course[i]->tut_classroom[j].c_str());
        }
    }
}

void printClassInfo(short n) {
    setfillcolor(RGB(186, 204, 217));
    solidrectangle(0, 0, 1280, 495);

    string work_dir = ".\\sis_ws\\data_repo\\class\\"+to_string(n)+".txt";
    FILE *file = fopen(work_dir.c_str(), "r");
    if (file== nullptr) {
        cout<<"[System Message] File could not be opened."<<endl;
        return;
    }
    int num_lec, num_tut, capacity;
    string instructor, courseCode, courseName;
    int lec[28], tut[28];
    string lec_classroom[28], tut_classroom[21];
    char fn[2000];
    fscanf(file, "%s", fn);
    instructor = string(fn);
    fscanf(file, "%s", fn);
    courseCode = string(fn);
    fscanf(file, "%d", &capacity);
    fscanf(file, "%d", &num_lec);
    for (int i = 0; i < num_lec; i++)
        fscanf(file, "%d", &lec[i]);
    fscanf(file, "%d", &num_tut);
    for (int i = 0; i < num_tut; i++)
        fscanf(file, "%d", &tut[i]);
    for (int i = 0; i < num_lec; i++) {
        fscanf(file, "%s", fn);
        lec_classroom[i] = string(fn);
    }
    for (int i = 0; i < num_tut; i++) {
        fscanf(file, "%s", fn);
        tut_classroom[i] = string(fn);
    }
    fclose(file);

    work_dir = ".\\sis_ws\\data_repo\\course\\"+courseCode+".txt";
    file = fopen(work_dir.c_str(), "r");
    if (file== nullptr) {
        cout<<"[System Message] File could not be opened."<<endl;
        return;
    }
    fscanf(file, "%[^\n]", fn);
    courseName = fn;
    // [todo] read more information from this file.
    fclose(file);

    RECT r0 = { 200, 70, 1080, 100 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(35, 0, _T("Arial"));
    drawtext(("Classes to arrange: " + to_string(n)).c_str(), &r0, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    string output;
    output = "Course Name: " + courseName + "\n\n" + "Course Code:" + courseCode + "\n\n" + "Instructor: " + instructor + "\n\n" + "Capacity: " + to_string(capacity) + "\n\n";
    output += "Number of lecs: " + to_string(num_lec)+ "\n" + "Index: ";
    for (int i = 0; i < num_lec; i++) output += to_string(lec[i]) + " ";
    output += "\n\nNumber of tuts: " + to_string(num_tut)+ "\n" + "Index: ";
    for (int i = 0; i < num_tut; i++) output += to_string(tut[i]) + " ";
    RECT r1 = { 250, 150, 1080, 540 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0, _T("Arial"));
    drawtext(output.c_str(), &r1, DT_LEFT | DT_WORDBREAK | DT_EXTERNALLEADING );

}

void arrangeClassConfirmPage() {
    setbkcolor(RGB(186, 204, 217));
    cleardevice();
    string work_dir = ".\\sis_ws\\data_repo\\class_claim\\registry\\to_claim_list.txt";
    FILE *file = fopen(work_dir.c_str(), "r");
    int n;
    fscanf(file, "%d", &n);
    fclose(file);
    string hint;
    if(n != 0) {
        hint = "Warning: some classes haven't been approved.\nBut you still can continue.\n\n";
    }
    else {
        hint = "All classes have been approved. It is safe to continue.\n\n";
    }
    hint += "Press the button and the procedure will automatically assign classroom to each class.";

    RECT r1 = { 200, 150, 1080, 540 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0, _T("Arial"));
    drawtext(hint.c_str(), &r1, DT_LEFT | DT_WORDBREAK | DT_EXTERNALLEADING );

    Button confirmButton;
    confirmButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    confirmButton.Draw(440, 400, 840, 500, 5, 5);
    confirmButton.setDefaultText(_T("Confirm To Arrange"), 30, _T("Arial Rounded MT Bold"), WHITE);
    Button backButton;
    backButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    backButton.Draw(440, 530, 840, 580, 5, 5);
    backButton.setDefaultText(_T("Back"), 30, _T("Arial"), WHITE);

    ExMessage mouseMonitor{};
    int to_do = 0;
    while(true) {
        mouseMonitor = getmessage(EX_MOUSE);
        const int x = mouseMonitor.x;
        const int y = mouseMonitor.y;
        confirmButton.changeWhileMouseInBox(x ,y);
        backButton.changeWhileMouseInBox(x ,y);
        if (mouseMonitor.message == WM_LBUTTONDOWN) {
            if (confirmButton.Check(x, y)) {
                usleep(5000);
                confirmButton.resetMouseStyle();
                to_do = 1;
                break;
            }
            if (backButton.Check(x, y)) {
                usleep(5000);
                backButton.resetMouseStyle();
                to_do = 2;
                break;
            }
        }
    }
    switch (to_do) {
        case 1:
            classroom_arrangement();
        case 2:
            Registry::arrangeClassPage();
    }


}

void Registry::arrangeClassPage() {

    string work_dir = ".\\sis_ws\\data_repo\\class\\";
    string index_path = work_dir + "Class Number.txt";
    FILE *file = fopen(index_path.c_str(), "r");
    int n;
    fscanf(file, "%d", &n);
    fclose(file);


    setbkcolor(RGB(186, 204, 217));
    cleardevice();
    Button previousPageButton;
    previousPageButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    previousPageButton.Draw(200, 560, 400, 600, 5, 5);
    previousPageButton.setDefaultText(_T("Previous Page"), 24, _T("Arial"), WHITE);
    Button nextPageButton;
    nextPageButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    nextPageButton.Draw(500, 560, 700, 600, 5, 5);
    nextPageButton.setDefaultText(_T("Next Page"), 24, _T("Arial"), WHITE);
    Button backButton;
    backButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    backButton.Draw(800, 560, 1000, 600, 5, 5);
    backButton.setDefaultText(_T("Back"), 24, _T("Arial"), WHITE);
    Button toArrangeButton;
    toArrangeButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    toArrangeButton.Draw(800, 500, 1000, 540, 5, 5);
    toArrangeButton.setDefaultText(_T("Click To Arrange"), 24, _T("Arial"), WHITE);

    ExMessage mouseMonitor{};
    int to_do = 0;

    short cur_n = 1;
    printClassInfo(cur_n);
    while(true) {
        mouseMonitor = getmessage(EX_MOUSE);
        const int x = mouseMonitor.x;
        const int y = mouseMonitor.y;
        previousPageButton.changeWhileMouseInBox(x, y);
        nextPageButton.changeWhileMouseInBox(x, y);  //启用控件的鼠标样式改变函数，达到在某控件触发时改变鼠标样式的效果
        backButton.changeWhileMouseInBox(x, y);
        toArrangeButton.changeWhileMouseInBox(x, y);

        if (mouseMonitor.message == WM_LBUTTONDOWN) {
            if (previousPageButton.Check(x, y)) {
                usleep(5000);
                previousPageButton.resetMouseStyle();
                if (cur_n > 1) {
                    cur_n -= 1;
                    printClassInfo(cur_n);
                }
            }
            if (nextPageButton.Check(x, y)) {
                usleep(5000);
                nextPageButton.resetMouseStyle();
                if (cur_n < n) {
                    cur_n += 1;
                    printClassInfo(cur_n);
                }
            }
            if (backButton.Check(x, y)) {
                usleep(5000);
                backButton.resetMouseStyle();
                to_do = 1;
                break;
            }
            if (toArrangeButton.Check(x, y)) {
                usleep(5000);
                toArrangeButton.resetMouseStyle();
                to_do = 2;
                break;
            }
        }
    }
    switch (to_do) {
        case 1:
            drawWidget();
        case 2:
            arrangeClassConfirmPage();
    }
}