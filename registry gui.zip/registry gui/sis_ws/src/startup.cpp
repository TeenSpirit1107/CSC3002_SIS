#include <unistd.h>
#include <iostream>
#include <easyx.h>
#include <thread>
#include <sstream>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <gui.hpp>
#include <registry.hpp>
#include <startup.hpp>
using namespace std;
// this code is for opening a new login page. There's no corresponding .hpp file for this .cpp, becaues it's not a class.

void log_in(){
    // login 
    return;   
}

void sign_in(){
    // sign up
    return;
}

// may suggest other functions
void startAnimation(){  //启动时ISIS的飞入效果
    std::string title = "Integrated Student Information System";
    settextcolor(WHITE);
    settextstyle(100, 53, _T("Arial Rounded MT Bold"));
    int deltaDistance = 30;  //每次移动的距离
    int title_targetPos_x = 120;
    int title_charPos_y = 120;
    for (int i = 0; i < title.length(); i++){
        if (title[i] != ' '){
            int title_charPos_x = title_targetPos_x+150;
            outtextxy(title_charPos_x, title_charPos_y, title[i]);  //起始位置先绘制一次
            while (title_charPos_x > title_targetPos_x){  //当未到目标位置时，持续移动字符
                usleep(1000); //挂起1000us
                settextcolor(RGB(138, 188, 209));
                outtextxy(title_charPos_x, title_charPos_y, title[i]);  //用背景色绘制字符，达到删除效果
                title_charPos_x -= deltaDistance;  //更新x坐标
                settextcolor(WHITE);
                outtextxy(title_charPos_x, title_charPos_y, title[i]);  //在新位置绘制字符
            }
            title_targetPos_x += textwidth(title[i]) - 15;
        }
        else{  //遇到空格换行
            title_charPos_y += 100;
            title_targetPos_x = 120;
        }
    }
}

void logInZone(){  //登录区域绘制
    constexpr int changeRate = 50;  //动画细分率
    constexpr double deltaR = (216.0 - 138.0)/changeRate;  //计算delta用于动画的淡入效果
    constexpr double deltaG = (227.0 - 188.0)/changeRate;
    constexpr double deltaB = (231.0 - 209.0)/changeRate;
    double curR = 138;
    double curG = 188;
    double curB = 209;
    int curTop = 150;
    int curBottom = 600;
    setfillcolor(RGB(curR,curG,curB));
    for (int i = 0; i < changeRate; i++){ //淡入动画的循环
        usleep(1000);
        curR += deltaR;  //更新位置
        curG += deltaG;
        curB += deltaB;
        setfillcolor(RGB(curR,curG,curB));  //更新颜色的rgb值
        curTop -= 1;
        curBottom -= 1;
        solidroundrect(750,curTop,1150,curBottom,15,15);
    }
    Button logInButton;  //设置属性，创建各个控件
    logInButton.setColor(RGB(86, 152, 195), RGB(22, 97, 171));
    logInButton.Draw(800, 430, 1100, 480, 15, 15);  //（左上角x，y坐标，右下角x，y坐标，圆角宽度，圆角长度）
    logInButton.setDefaultText(_T("Log in"), 35, _T("Arial Rounded MT Bold"), WHITE);
    TextBox usernameBox;
    usernameBox.setBackColor(RGB(216, 227, 231));
    usernameBox.Draw(800,1100,250);  //（左端点x坐标，右端点x坐标，横线底部y坐标）
    usernameBox.setDefaultText(_T("Username"),24, _T("Arial"),RGB(80,80,80));
    TextBox passwordBox;
    passwordBox.setBackColor(RGB(216, 227, 231));
    passwordBox.Draw(800,1100,350);
    passwordBox.setDefaultText(_T("Password"),24, _T("Arial"),RGB(80,80,80));
    ExMessage mouseMonitor{};
    int to_do = 0;
    while(true){  //鼠标事件监测循环
        mouseMonitor = getmessage(EX_MOUSE);
        const int x = mouseMonitor.x;
        const int y = mouseMonitor.y;
        usernameBox.changeWhileMouseInBox(x,y);  //启用各个控件的鼠标样式改变函数，达到在某控件触发时改变鼠标样式的效果
        passwordBox.changeWhileMouseInBox(x,y);
        logInButton.changeWhileMouseInBox(x, y);
        if (mouseMonitor.message == WM_LBUTTONDOWN){  //左键按下时，三个if监测鼠标按了哪个控件
            if(usernameBox.Check(x,y)){
                usernameBox.initialize(x,y);  //初始化文本框，开启各线程
                std::cout << usernameBox.value() << std::endl;
            }
            if(passwordBox.Check(x,y)){
                passwordBox.initialize(x,y);
                std::cout << passwordBox.value() << std::endl;
            }
            if(logInButton.Check(x, y)){  //当按钮按下时
                usleep(5000);
                logInButton.resetMouseStyle();
                to_do = 1;
                break;
            }
        }
    }
    switch (to_do) {
        case 1:
            Registry::createRegistryPage();  //跳转到registry
        break;
    }
}

void Startup::loadFirstPage(){
    setbkcolor(RGB(138, 188, 209));  //设置背景色
    cleardevice();  //用背景色清空屏幕
    settextcolor(BLACK);
    startAnimation();  //唤起字体动画
    logInZone();  //绘制登录区域
}

int main(){
    // main function here
    initgraph(1280, 720);
    const int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    const int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    const int x = (screenWidth - 1280)/2;
    const int y = (screenHeight - 720)/2;  //计算屏幕坐标，使窗口居中
    HWND hwnd = GetHWnd();
    SetWindowPos(hwnd, NULL, x, y, 1280, 720, SWP_SHOWWINDOW);
    Startup::loadFirstPage();
}