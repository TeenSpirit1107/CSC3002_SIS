#include <gui.hpp>
#include <windows.h>
#include <chrono>
#include <ctime>
#include <fstream>
#include <easyx.h>
#include <string>
#include <iomanip>
#include <iostream>
#include <ostream>
#include <conio.h>
#include <unistd.h>
#include <vector>
#include <thread>
#include <sstream>
#include <registry.hpp>

using namespace std;

Announcement::Announcement() {
    this->textLineCount = 0;
    this->title = "";
    this->text = "";
    this->promoter = "";
    this->targetUser = "";
    this->promoteTime = "";
    this->readState = "";
}

Announcement::~Announcement() = default;

void Announcement::setContent(string title, string text) {
    this->title = std::move(title);
    this->text = std::move(text);
}

void Announcement::setPromoter(string promoter) {
    this->promoter = std::move(promoter);
}

void Announcement::setTarget(string idCode) {
    this->targetUser = std::move(idCode);
}

void Announcement::send() {
    HANDLE hFind;
    WIN32_FIND_DATA FindFileData;
    char working_dir[] = R"(.\sis_ws\data_repo\announcements\)";
    strcat(working_dir, targetUser.c_str());
    CreateDirectory(working_dir, nullptr);  //create an ID folder if it didn't exist
    strcat(working_dir, "\\*.*");
    hFind = FindFirstFile(working_dir, &FindFileData);
    int maxNum = 0;
    if (hFind == INVALID_HANDLE_VALUE) {  //no file in the folder
        maxNum = 0;
    } else {
        while (FindNextFile(hFind, &FindFileData)) {  //find max n.txt from 1.txt 2.txt ...
            CHAR *num = FindFileData.cFileName;
            const size_t len = strlen(num);
            if (len >= 4) {
                num[len - 4] = '\0';
                const char cur_num = *num;
                if (cur_num -'0'> maxNum) {
                    maxNum = cur_num - '0';
                }
            }
        }
    }
    if (!text.empty()) {  //record possible \n in text
        int newlineCount = 0;
        for (const char ch : text) {
            if (ch == '\n') {
                ++newlineCount;
            }
        }
        textLineCount = newlineCount;
    }
    const auto now = chrono::system_clock::now();
    const time_t now_time_t = chrono::system_clock::to_time_t(now);  //get time
    const tm* now_tm = std::localtime(&now_time_t);
    ofstream outfile(R"(.\sis_ws\data_repo\announcements\)" + targetUser + "\\" + to_string(maxNum + 1) + ".txt");
    if (!outfile.is_open()) {
        cout << "Failed to open file for writing." << endl;
    }else {
        outfile << to_string(textLineCount) + "\n";
        outfile << title + "\n";
        outfile << text + "\n";
        outfile << promoter + "\n";
        outfile << put_time(now_tm, "%Y-%m-%d %H:%M:%S");
    }
    outfile.close();
}


void Announcement::setCurUserId(const string& idCode) {
    cur_user_id = idCode;
}

int Announcement::getMaxTxt(const string& idCode) {
    HANDLE hFind;
    WIN32_FIND_DATA FindFileData;
    char working_dir[] = R"(.\sis_ws\data_repo\announcements\)";
    strcat(working_dir, idCode.c_str());
    CreateDirectory(working_dir, nullptr);  //create an ID folder if it didn't exist
    strcat(working_dir, "\\*.*");
    hFind = FindFirstFile(working_dir, &FindFileData);
    int maxNum = 0;
    if (hFind == INVALID_HANDLE_VALUE) {  //no file in the folder
        maxNum = 0;
    } else {
        while (FindNextFile(hFind, &FindFileData)) {  //find max n.txt from 1.txt 2.txt ...
            CHAR *num = FindFileData.cFileName;
            const size_t len = strlen(num);
            if (len >= 4) {
                num[len - 4] = '\0';
                const char cur_num = *num;
                if (cur_num -'0'> maxNum) {
                    maxNum = cur_num - '0';
                }
            }
        }
    }
    return maxNum;
}

void Announcement::readFile(const int fileNum) {
    ifstream file(R"(.\sis_ws\data_repo\announcements\)" + cur_user_id + "\\" + to_string(fileNum) + ".txt");
    if (!file.is_open()) {
        cout << "Failed to open file for reading." << endl;
    }
    else {
        string lineCount;
        getline(file, lineCount);
        textLineCount = stoi(lineCount);
        getline(file, title);
        for (int i = 0; i < textLineCount + 1; ++i) {
            string text_in_line;
            getline(file, text_in_line);
            text += text_in_line + "\n";
        }
        getline(file, promoter);
        cout << promoter;
        getline(file,promoteTime);
        getline(file, readState);
    }
    file.close();
    cout << readState;
    if (readState.empty()) {
        cout << "It is empty." << endl;
        ofstream writeFile(R"(.\sis_ws\data_repo\announcements\)" + cur_user_id + "\\" + to_string(fileNum) + ".txt", std::ios::app);
        if (writeFile.is_open()) {
            cout << "File opened." << endl;
            writeFile << "\n1";
        }
        writeFile.close();
    }
}

string Announcement::getTitle() {
    return title;
}

string Announcement::getText() {
    return text;
}

string Announcement::getPromoter() {
    return promoter;
}

string Announcement::getPromoteTime() {
    return promoteTime;
}

bool Announcement::getReadState() const {
    if (!readState.empty()) {
        return true;
    } else {
        return false;
    }
}


void printMessage(const string& idCode, int num) {
    setfillcolor(RGB(186, 204, 217));
    solidrectangle(0, 0, 1280, 540);
    Announcement message;
    message.setCurUserId(idCode);
    message.readFile(num);
    RECT r0 = { 200, 70, 1080, 100 };
    setbkcolor(RGB(186, 204, 217));
    if (!message.getReadState()) {
        settextcolor(RED);
    }
    else {
        settextcolor(BLACK);
    }
    settextstyle(30, 0, _T("Arial"));
    drawtext(("Message: " + to_string(num)).c_str(), &r0, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT r1 = { 200, 160, 1080, 200 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(40, 0, _T("Arial"));
    drawtext(message.getTitle().c_str(), &r1, DT_LEFT | DT_VCENTER | DT_SINGLELINE | FW_BOLD);
    RECT r2 = { 200, 220, 1080, 460 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0, _T("Arial"));
    drawtext(message.getText().c_str(), &r2, DT_LEFT | DT_WORDBREAK);
    RECT r3 = { 200, 460, 1080, 485 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0, _T("Arial"));
    drawtext(message.getPromoter().c_str(), &r3, DT_LEFT | DT_VCENTER);
    RECT r4 = { 200, 500, 1080, 525 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(25, 0, _T("Arial"));
    drawtext(message.getPromoteTime().c_str(), &r4, DT_LEFT | DT_VCENTER);
}
void AnnouncementPage::messagePage() {
    setbkcolor(RGB(186, 204, 217));
    cleardevice();
    const int messageNum = Announcement::getMaxTxt("0000000");
    int cur_msg = messageNum;
    printMessage("0000000", cur_msg);
    Button previousPageButton;
    previousPageButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    previousPageButton.Draw(200, 560, 400, 600, 5, 5);
    previousPageButton.setDefaultText(_T("Previous Page"), 24, _T("Arial"), WHITE);
    Button nextPageButton;
    nextPageButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    nextPageButton.Draw(500, 560, 700, 600, 5, 5);
    nextPageButton.setDefaultText(_T("Next Page"), 24, _T("Arial"), WHITE);
    Button backButton;
    backButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    backButton.Draw(800, 560, 1000, 600, 5, 5);
    backButton.setDefaultText(_T("Back"), 24, _T("Arial"), WHITE);
    ExMessage mouseMonitor{};
    int to_do = 0;
    while(true) {
        mouseMonitor = getmessage(EX_MOUSE);
        const int x = mouseMonitor.x;
        const int y = mouseMonitor.y;
        previousPageButton.changeWhileMouseInBox(x, y);
        nextPageButton.changeWhileMouseInBox(x, y);  //启用控件的鼠标样式改变函数，达到在某控件触发时改变鼠标样式的效果
        backButton.changeWhileMouseInBox(x, y);
        if (mouseMonitor.message == WM_LBUTTONDOWN) {
            if (previousPageButton.Check(x, y)) {
                usleep(5000);
                previousPageButton.resetMouseStyle();
                if (cur_msg < messageNum) {
                    cur_msg += 1;
                    printMessage("0000000", cur_msg);
                }
            }
            if (nextPageButton.Check(x, y)) {
                usleep(5000);
                nextPageButton.resetMouseStyle();
                if (cur_msg > 1) {
                    cur_msg -= 1;
                    printMessage("0000000", cur_msg);
                }
            }
            if (backButton.Check(x, y)) {
                usleep(5000);
                backButton.resetMouseStyle();
                to_do = 1;
                break;
            }
        }
    }
    switch (to_do) {
        case 1:
            Registry::drawWidget();
    }
}

Button::Button(){
    this->defaultText = "button";
    this->defaultTextSize = 20;
    this->defaultTextFont = "Arial";
    this->defaultTextColor = BLACK;
    this->defaultButtonColor = WHITE;
    this->mouseInButtonColor = RED;
}

Button::~Button() = default;

void Button::Draw(const int topLeft_x, const int topLeft_y, const int downRight_x, const int downRight_y, const int el_width, const int el_height){  //绘制按钮
    left = topLeft_x;
    top = topLeft_y;
    right = downRight_x;
    bottom = downRight_y;
    ellipsewidth = el_width;
    ellipseheight = el_height;
    solidroundrect(left,top,right,bottom,ellipsewidth,ellipseheight);
}

void Button::setColor(const COLORREF theColor, const COLORREF mouseInColor){  //设置按钮默认颜色（无操作时的颜色，鼠标悬停于按钮上的颜色）
    defaultButtonColor = theColor;
    mouseInButtonColor = mouseInColor;
    setbkcolor(theColor);
    setfillcolor(theColor);
}

void Button::setDefaultText(const LPCTSTR defaultStr, const int textSize, const LPCTSTR textFont, COLORREF textColor){  //设置按钮默认文本
    defaultText = defaultStr;
    defaultTextSize = textSize;
    defaultTextFont = textFont;
    defaultTextColor = textColor;
    RECT r = { left, top, right, bottom };
    settextcolor(textColor);
    settextstyle(textSize, 0,textFont);
    drawtext(defaultText, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

void Button::changeWhileMouseInBox(const int x, const int y){  //鼠标悬停时按钮变化，改变按钮颜色及鼠标样式
    HWND hwnd = GetHWnd();
    if (Check(x,y)){
        if (mouseStyle == 0){
            changeButtonColor(mouseInButtonColor);
            HCURSOR hcur = LoadCursor(NULL, IDC_HAND);  //加载手型鼠标样式
            SetClassLongPtrA(hwnd, GCLP_HCURSOR, reinterpret_cast<LONG_PTR>(hcur)); //应用更改
            mouseStyle = 1;
        }
    }
    else{  //当鼠标离开按钮时，恢复其样式
        if (mouseStyle == 1){
            changeButtonColor(defaultButtonColor);
            HCURSOR hcur = LoadCursor(NULL, IDC_ARROW);  //加载箭头鼠标样式
            SetClassLongPtrA(hwnd, GCLP_HCURSOR, reinterpret_cast<LONG_PTR>(hcur)); //还原更改
            mouseStyle = 0;
        }
    }
}

void Button::resetMouseStyle(){
    HWND hwnd = GetHWnd();
    changeButtonColor(defaultButtonColor);
    HCURSOR hcur = LoadCursor(NULL, IDC_ARROW);  //加载箭头鼠标样式
    SetClassLongPtrA(hwnd, GCLP_HCURSOR, reinterpret_cast<LONG_PTR>(hcur)); //还原更改
    mouseStyle = 0;
}

bool Button::Check(const int x, const int y) const  //检验函数，用于页面发生单击事件时，检验鼠标是否在控件中
{
    const bool mouseInBlock = left <= x && x <= right && top <= y && y <= bottom;
    return (mouseInBlock);
}

void Button::changeButtonColor(const COLORREF theColor){  //改变按钮颜色
    setbkcolor(0);
    setfillcolor(theColor);
    solidroundrect(left,top,right,bottom,ellipsewidth,ellipseheight);
    setbkcolor(theColor);  //重绘按钮及按钮文本
    setDefaultText(defaultText,defaultTextSize,defaultTextFont,defaultTextColor);
}


TextBox::TextBox() {
    this->defaultText = "TextBox";
    this->defaultTextFont = "Arial";
    this->defaultTextColor = BLACK;
    this->defaultBackColor = WHITE;
    this->lineNum = 1;
    this->lineNumLimit = 5;
}

TextBox::~TextBox() = default;

void TextBox::Draw(const int left_x, const int right_x,const int line_y){  //绘制文本框
    left = left_x;
    enter_x = left;
    right = right_x;
    bottom = line_y;
    setlinecolor(BLACK);
    setlinestyle(PS_SOLID,2);
    line(left,bottom,right,bottom);
}

void TextBox::setBackColor(const COLORREF theColor){  //设置文本框底部横线默认颜色
    setbkcolor(theColor);
    defaultBackColor = theColor;
}

void TextBox::setDefaultText(const LPCTSTR defaultStr, const int textSize, const LPCTSTR textFont, const COLORREF textColor){  //设置文本框无输入默认文本
    defaultText = defaultStr;
    defaultTextSize = textSize;
    defaultTextFont = textFont;
    defaultTextColor = textColor;
    RECT r = { left , bottom - 26, right, bottom };
    settextcolor(textColor);
    settextstyle(textSize, 0, textFont);
    drawtext(defaultText, &r, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
}

void TextBox::initialize(const int x, const int y){  //初始化文本框，开启三个同时进行的线程
    if (!Check(x,y)){
        typing = false;
    }
    std::thread t1([this]{cursorBlinking();});  //光标闪烁进程
    std::thread t2([this]{Type();});  //等待输入进程
    std::thread t3([this]{mouseInBoxCheck();});  //鼠标位置检测进程
    t1.join();
    t2.join();
    t3.join();
    std::cout << "Init ended" << std::endl;
    if (textLen == 0){
        setDefaultText(defaultText,defaultTextSize,defaultTextFont,defaultTextColor);
    }
}

void TextBox::mouseInBoxCheck(){  //循环检测鼠标是否在文本框中
    ExMessage mouseMonitor{};
    int x = mouseMonitor.x;
    int y = mouseMonitor.y;
    while(typing){
        mouseMonitor =  getmessage(EX_MOUSE);
        if (mouseMonitor.message == WM_LBUTTONDOWN && !Check(x,y)){  //若在文本框外按下左键，终止输入状态
            typing = false;
            std::cout << "Typing stop" << std::endl;
            keybd_event(VK_RETURN,0,0,0); //按下enter，使Type()跳出_getch()等待状态
            break;
        }
    }
    std::cout << "InBoxCheck ended" << std::endl;
}

void TextBox::changeWhileMouseInBox(const int x,const int y){  //改变鼠标光标
    HWND hwnd = GetHWnd();
    if (Check(x,y)){
        if (mouseStyle == 0){
            HCURSOR hcur = LoadCursor(NULL, IDC_IBEAM);  //加载I型鼠标样式
            SetClassLongPtrA(hwnd, GCLP_HCURSOR, reinterpret_cast<LONG_PTR>(hcur)); //应用更改
            mouseStyle = 1;
        }
    }
    else{  //若鼠标在文本框外，还原光标
        if (mouseStyle == 1){
            HCURSOR hcur = LoadCursor(NULL, IDC_ARROW);  //加载I型鼠标样式
            SetClassLongPtrA(hwnd, GCLP_HCURSOR, reinterpret_cast<LONG_PTR>(hcur)); //还原更改
            mouseStyle = 0;
        }
    }
}

bool TextBox::Check(const int x, const int y)  //检验函数，用于页面发生单击事件时，检验鼠标是否在控件中
{
    bool mouseInBlock = left <= x && x <= right && bottom - 40 <= y && y <= bottom;
    if (mouseInBlock){
        typing = true;
    }
    else{
        typing = false;
    }
    return (mouseInBlock);
}

void TextBox::changeLineColor(const COLORREF lineColor) const{  //设置输入状态时，文本框底部横线的颜色
    setlinestyle(PS_SOLID,2);
    setlinecolor(lineColor);
    line(left,bottom,right,bottom);
}

void TextBox::cursorBlinking() const{  //光标闪烁函数
    int curCursorPos_x = enter_x;
    int curCursorPos_y = bottom;
    while (typing){
        if (curCursorPos_x != enter_x){
            curCursorPos_x = enter_x;
        }
        if (curCursorPos_y != bottom) {
            curCursorPos_y = bottom;
        }
        setlinestyle(PS_SOLID,2);
        setlinecolor(RGB(21,85,154));
        line(curCursorPos_x,curCursorPos_y-24,curCursorPos_x,curCursorPos_y-3);
        usleep(500000);  //等待半秒
        setlinecolor(defaultBackColor);
        line(curCursorPos_x,curCursorPos_y-24,curCursorPos_x,curCursorPos_y-3);
        usleep(500000);
    }
    std::cout << "cursor ended" << std::endl;
}

void TextBox::Type(){  //输入检测函数
    changeLineColor(RGB(21,85,154));
    if (textLen == 0){
        setbkcolor(defaultBackColor);
        clearrectangle(left , bottom - 26, right, bottom - 2);
    }
    settextcolor(RGB(50,50,50));
    settextstyle(24, 0, _T("Arial"));
    if (!enter_x){
        enter_x = left;  //初始化输入坐标
    }
    while(typing){
        int ch = _getch(); //得到输入按键的ASCII码
        char char_ch =(char)ch; //将ASCII码转成char型
        switch(ch){
            case '\b':  //输入退格时，删除一位数
                if (textLen > 0){
                    settextcolor(defaultBackColor);
                    char del_letter = textInBox.back();  //从vector中取出最后一位数字
                    std::cout << del_letter << std:: endl;
                    enter_x -= textwidth(del_letter) + 1;  //计算最后一位数字的坐标
                    outtextxy(enter_x,bottom-25,del_letter);  //重绘数字，颜色于背景色相同，达到删除效果
                    std::cout << enter_x << bottom - 25 << std:: endl;
                    settextcolor(RGB(50,50,50));
                    textInBox.pop_back();  //从vector中删除此位数字
                    textLen -= 1;

                    if (enter_x < left + textwidth(textInBox.back()) && lineNum > 1) {
                        lineNum -= 1;
                        setlinecolor(defaultBackColor);
                        setlinestyle(PS_SOLID,2);
                        line(left,bottom,right,bottom);

                        bottom -= 25;
                        setlinecolor(RGB(21,85,154));
                        setlinestyle(PS_SOLID,2);
                        line(left,bottom,right,bottom);
                        enter_x = right;
                    }
                }
                break;
            case '\r':
            case '\n':  //键盘输入enter时，结束输入状态
                typing = false;
                changeLineColor(BLACK);  //恢复文本框颜色为黑色
                break;
            default:  //正常输入状态
                if (textInBox.empty() || enter_x < right - textwidth(textInBox.back())){
                    std::cout << "typing" << char_ch << std::endl;
                    textInBox.push_back(char_ch);  //将字符加入到vector中
                    textLen += 1;
                    outtextxy(enter_x,bottom-25,char_ch);  //绘制数字
                    enter_x += textwidth(char_ch) + 1;  //更新输入位置坐标
                }
                else if (multiLines && lineNum < lineNumLimit){
                    lineNum += 1;
                    setlinecolor(defaultBackColor);
                    setlinestyle(PS_SOLID,2);
                    line(left,bottom,right,bottom);

                    bottom += 25;
                    setlinecolor(RGB(21,85,154));
                    setlinestyle(PS_SOLID,2);
                    line(left,bottom,right,bottom);

                    enter_x = left;
                    std::cout << "typing" << char_ch << std::endl;
                    textInBox.push_back(char_ch);  //将字符加入到vector中
                    textLen += 1;
                    outtextxy(enter_x,bottom-25,char_ch);  //绘制数字
                    enter_x += textwidth(char_ch) + 1;  //更新输入位置坐标
                }

        }
    }
    std::cout << "type ended" << std::endl;
}

void TextBox::setMultiLines(const bool isMultiLines) {
    multiLines = isMultiLines;
}

void TextBox::setLineLimit(const int lineNum) {
    lineNumLimit = lineNum;
}


std::string TextBox::value(){  //输出文本框中的字符
    std::stringstream ss;
    std::string result;
    for (char letter: textInBox){
        ss << letter;
    }
    result = ss.str();
    return result;
}

TextBoxPage::TextBoxPage() {
    this->input = "";
}

TextBoxPage::~TextBoxPage() =default;


bool TextBoxPage::createTextBoxPage(const string& title) {
    setbkcolor(RGB(186, 204, 217));
    cleardevice();
    RECT r1 = { 200, 160, 1080, 200 };
    setbkcolor(RGB(186, 204, 217));
    settextcolor(BLACK);
    settextstyle(40, 0, _T("Arial"));
    drawtext(title.c_str(), &r1, DT_LEFT | DT_VCENTER | DT_SINGLELINE | FW_BOLD);
    TextBox aTextBox;
    aTextBox.setBackColor(RGB(186, 204, 217));
    aTextBox.Draw(200,1080,300);  //（左端点x坐标，右端点x坐标，横线底部y坐标）
    aTextBox.setDefaultText(_T("Write something?"),24, _T("Arial"),RGB(80,80,80));
    aTextBox.setMultiLines(true);
    aTextBox.setLineLimit(5);
    Button confirmButton;
    confirmButton.setColor(RGB(179, 101, 154), RGB(92, 179, 204));
    confirmButton.Draw(880, 560, 1080, 600, 5, 5);
    confirmButton.setDefaultText(_T("Confirm"), 24, _T("Arial"), WHITE);
    ExMessage mouseMonitor{};
    while(true) {
        mouseMonitor = getmessage(EX_MOUSE);
        const int x = mouseMonitor.x;
        const int y = mouseMonitor.y;
        aTextBox.changeWhileMouseInBox(x, y);
        confirmButton.changeWhileMouseInBox(x, y);
        if (mouseMonitor.message == WM_LBUTTONDOWN) {
            if (aTextBox.Check(x, y)) {
                aTextBox.initialize(x, y);
            }
            if (confirmButton.Check(x, y)) {
                usleep(5000);
                input = aTextBox.value();
                confirmButton.resetMouseStyle();
                return true;
            }
        }
    }
}

string TextBoxPage::getInput() {
    return input;
}
